<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('share_lineup', function (Blueprint $table) {
            $table->softDeletes(); // adds nullable deleted_at timestamp
        });
    }

    public function down(): void
    {
        Schema::table('share_lineup', function (Blueprint $table) {
            $table->dropSoftDeletes();
        });
    }
};

<?php

namespace App\Models;

class Payment extends BaseAppendOnlyModel
{
    protected $fillable = [
        'phone',
        'amount',
    ];

    protected $casts = [
        'amount' => 'integer',
    ];
}

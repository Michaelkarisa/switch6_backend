<?php

namespace App\Models;

class Transaction extends BaseAppendOnlyModel
{
    protected $fillable = [
        'phone',
        'amount',
        'status',
    ];

    protected $casts = [
        'amount' => 'integer',
    ];
}

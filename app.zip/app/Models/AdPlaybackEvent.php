<?php

namespace App\Models;

class AdPlaybackEvent extends BaseAppendOnlyModel
{
    protected $fillable = [
        'advertisement_id',
        'match_id',
        'stream_id',
        'platform',
        'play_time',
        'viewer_count',
        'context',
    ];

    protected $casts = [
        'context' => 'array',
    ];
}

<?php
namespace App\Middleware;
use Closure;
use Illuminate\Http\Request;
class EnsureAdmin {
    public function handle(Request $request, Closure $next) {
        if (! $request->user()?->hasRole('admin')) {
            return response()->json(['success' => false, 'message' => 'Super Admin access required', 'data' => null], 403);
        }
        return $next($request);
    }
}

<?php

namespace App\Services;

use App\Models\League;
use App\Models\MatchModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class MatchService
{
    private const STATUSES = [
        'scheduled',
        'live',
        'finished',
        'cancelled',
    ];

    public function __construct(
        private MatchFormatterService $formatter,
        private AuditLogService $audit,
        private NotificationService $notifications,
    ) {}

    /* -------------------------------------------------
     |  PUBLIC API
     | ------------------------------------------------- */

    public function create(array $data, ?string $authorId, ?Request $request = null): array
    {
        $this->validateMatchPayload($data);

        $match = DB::transaction(function () use ($data, $authorId, $request) {
            $match = MatchModel::create(
                $this->buildPayload($data, $authorId)
            );

            $match->load($this->relations());

            $this->audit->log(
                'created',
                'matches',
                'Match created',
                ['match_id' => $match->id],
                $match,
                $request
            );

            return $match;
        });

        DB::afterCommit(function () use ($match) {
            $this->notifications->notifyMatchCreated($match);
        });

        return [
            'match'     => $match,
            'formatted' => $this->formatter->format($match),
        ];
    }

    public function createMany(array $items, ?string $authorId, ?Request $request = null): array
    {
        $created = DB::transaction(function () use ($items, $authorId, $request) {
            $created = [];

            foreach ($items as $data) {
                $this->validateMatchPayload($data);

                if (($data['home_club_id'] ?? null) === ($data['away_club_id'] ?? null)) {
                    continue;
                }

                $created[] = MatchModel::create(
                    $this->buildPayload($data, $authorId)
                );
            }

            $this->audit->log(
                'created_many',
                'matches',
                'Matches batch created',
                ['count' => count($created)],
                null,
                $request
            );

            return $created;
        });

        $created = collect($created)->load($this->relations());

        DB::afterCommit(function () use ($created) {
            foreach ($created as $match) {
                $this->notifications->notifyMatchCreated($match);
            }
        });

        return $created
            ->map(fn (MatchModel $match) => $this->formatter->format($match))
            ->values()
            ->all();
    }

    public function updateStatus(
        MatchModel $match,
        string $status,
        ?Request $request = null
    ): MatchModel {
        $this->assertValidStatus($status);

        $oldStatus = $match->status;

        $match = DB::transaction(function () use ($match, $status, $request) {
            $match->update(['status' => $status]);
            $match->load($this->relations());

            $this->audit->log(
                'status_updated',
                'matches',
                'Match status updated',
                [
                    'old_status' => $oldStatus ?? $match->getOriginal('status'),
                    'new_status' => $status,
                ],
                $match,
                $request
            );

            return $match;
        });

        DB::afterCommit(function () use ($match, $oldStatus, $status) {
            $this->notifications->notifyMatchStatusUpdated(
                $match,
                $oldStatus,
                $status
            );
        });

        return $match;
    }

    public function delete(MatchModel $match, ?Request $request = null): string
    {
        return DB::transaction(function () use ($match, $request) {
            $matchId = $match->id;

            $this->audit->log(
                'deleted',
                'matches',
                'Match deleted',
                ['match_id' => $matchId],
                $match,
                $request
            );

            $match->delete();

            return $matchId;
        });
    }

    /* -------------------------------------------------
     |  QUERY METHODS
     | ------------------------------------------------- */

    public function listFormatted()
    {
        return MatchModel::with($this->relations())
            ->orderBy('match_date')
            ->get()
            ->mapWithKeys(fn ($m) => [$m->id => $this->formatter->format($m)]);
    }

    public function paginatedFormatted(int $limit = 20, int $offset = 0)
    {
        return MatchModel::with($this->relations())
            ->orderBy('match_date')
            ->skip($offset)
            ->take($limit)
            ->get()
            ->mapWithKeys(fn ($m) => [$m->id => $this->formatter->format($m)]);
    }

    public function format(MatchModel $match): array
    {
        $match->loadMissing($this->relations());

        return $this->formatter->format($match);
    }

    public function byStatus(string $status)
    {
        $this->assertValidStatus($status);

        return MatchModel::with($this->relations())
            ->where('status', $status)
            ->orderBy('match_date')
            ->get()
            ->mapWithKeys(fn ($m) => [$m->id => $this->formatter->format($m)]);
    }

    public function byLeague(string $leagueName)
    {
        $leagueIds = League::query()
            ->where('leaguename', 'like', "%{$leagueName}%")
            ->orWhere('name', 'like', "%{$leagueName}%")
            ->pluck('id');

        return MatchModel::with($this->relations())
            ->whereIn('league_id', $leagueIds)
            ->orderBy('match_date')
            ->get()
            ->mapWithKeys(fn ($m) => [$m->id => $this->formatter->format($m)]);
    }

    public function byAuthor(string $authorId)
    {
        return MatchModel::with($this->relations())
            ->where('author_id', $authorId)
            ->orderByDesc('match_date')
            ->get()
            ->mapWithKeys(fn ($m) => [$m->id => $this->formatter->format($m)]);
    }

    /* -------------------------------------------------
     |  CORE HELPERS
     | ------------------------------------------------- */

    private function buildPayload(array $data, ?string $authorId): array
    {
        return [
            'match_date'     => $data['match_date'],

            'home_score'     => $data['home_score'] ?? 0,
            'away_score'     => $data['away_score'] ?? 0,

            'status'         => $data['status'] ?? 'scheduled',
            'venue'          => $data['venue'] ?? null,

            'referee'        => $data['referee'] ?? ($data['referee_id'] ?? null),
            'referee_id'     => $data['referee_id'] ?? null,

            'home_formation' => $data['home_formation'] ?? '4-4-2',
            'away_formation' => $data['away_formation'] ?? '4-4-2',

            'home_club_id'   => $data['home_club_id'],
            'away_club_id'   => $data['away_club_id'],

            'league_id'      => $data['league_id'] ?? ($data['leagueid'] ?? null),

            'author_id'      => $authorId,
        ];
    }

    private function validateMatchPayload(array $data): void
    {
        if (empty($data['match_date'])) {
            throw ValidationException::withMessages([
                'match_date' => ['Match date is required.'],
            ]);
        }

        if (empty($data['home_club_id'])) {
            throw ValidationException::withMessages([
                'home_club_id' => ['Home club is required.'],
            ]);
        }

        if (empty($data['away_club_id'])) {
            throw ValidationException::withMessages([
                'away_club_id' => ['Away club is required.'],
            ]);
        }

        if (($data['home_club_id'] ?? null) === ($data['away_club_id'] ?? null)) {
            throw ValidationException::withMessages([
                'away_club_id' => ['Home club and away club cannot be the same.'],
            ]);
        }

        if (!empty($data['status'])) {
            $this->assertValidStatus($data['status']);
        }
    }

    private function relations(): array
    {
        return [
            'homeClub',
            'awayClub',
            'league',
            'refereeRecord',
            'author',
        ];
    }

    private function assertValidStatus(string $status): void
    {
        if (!in_array($status, self::STATUSES, true)) {
            throw ValidationException::withMessages([
                'status' => [
                    'Invalid status. Must be one of: scheduled, live, finished, cancelled',
                ],
            ]);
        }
    }

 public function update(
    MatchModel $match,
    array $data,
    ?Request $request = null
): MatchModel {

    $this->validateMatchPayload(array_merge(
        $match->toArray(),
        $data
    ));

    $oldData = $match->only([
        'match_date',
        'status',
        'venue',
        'league_id',
        'home_club_id',
        'away_club_id',
    ]);

    $match = DB::transaction(function () use (
        $match,
        $data,
        $request
    ) {

        $match->update([
            'match_date'     => $data['match_date'] ?? $match->match_date,

            'home_score'     => $data['home_score'] ?? $match->home_score,
            'away_score'     => $data['away_score'] ?? $match->away_score,

            'status'         => $data['status'] ?? $match->status,

            'venue'          => $data['venue'] ?? $match->venue,

            'referee'        => $data['referee']
                ?? ($data['referee_id'] ?? $match->referee),

            'referee_id'     => array_key_exists('referee_id', $data)
                ? $data['referee_id']
                : $match->referee_id,

            'home_formation' => $data['home_formation']
                ?? $match->home_formation,

            'away_formation' => $data['away_formation']
                ?? $match->away_formation,

            'home_club_id'   => $data['home_club_id']
                ?? $match->home_club_id,

            'away_club_id'   => $data['away_club_id']
                ?? $match->away_club_id,

            // IMPORTANT:
            // allows null => friendly match
            'league_id'      => array_key_exists('league_id', $data)
                ? $data['league_id']
                : $match->league_id,
        ]);

        $match->load($this->relations());

        $this->audit->log(
            'updated',
            'matches',
            'Match updated',
            [
                'match_id' => $match->id,
            ],
            $match,
            $request
        );

        return $match;
    });

   // DB::afterCommit(function () use ($match, $oldData) {

     //   $this->notifications->notifyMatchUpdated(
     //       $match,
     //       $oldData
     //   );
   // });

    return $match;
}

}
<?php

namespace App\Services;

use App\Models\AuditLog;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class AuditLogService
{
    public function log(
        string $action,
        ?string $module = null,
        ?string $description = null,
        array $metadata = [],
        ?Model $auditable = null,
        ?Request $request = null,
        ?string $userId = null,
    ): void {
        try {
            $request ??= request();
            $user = $request?->user();

            $audit = AuditLog::create([
                'user_id' => $userId ?? $user?->id,
                'action' => $action,
                'module' => $module,
                'reference_id' => $auditable?->getKey(),
                'description' => $description,
                'ip_address' => $request?->ip(),
                'user_agent' => $request?->userAgent(),
                'metadata' => $metadata ?: null,
            ]);

            Log::info('Audit log created', [
                'audit_id' => $audit->id,
                'action' => $action,
                'module' => $module,
                'reference_id' => $auditable?->getKey(),
            ]);
        } catch (\Throwable $e) {
            Log::warning('Audit logging failed', [
                'action' => $action,
                'module' => $module,
                'error' => $e->getMessage(),
            ]);
        }
    }
}
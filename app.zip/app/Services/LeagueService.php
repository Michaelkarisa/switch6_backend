<?php

namespace App\Services;

use App\Models\League;

class LeagueService
{
    public function __construct(private AuditLogService $audit) {}

    public function list(?string $search = null)
    {
        return League::query()
            ->when($search, fn ($q) => $q->where(fn ($x) => $x->where('leaguename', 'like', "%{$search}%")->orWhere('name', 'like', "%{$search}%")))
            ->orderBy('leaguename')
            ->get();
    }

    public function create(array $data): League
    {
        $data['name'] = $data['name'] ?? $data['leaguename'];
        $league = League::create($data);
        $this->audit->log('created', 'leagues', 'League created', ['league_id' => $league->id], $league);
        return $league;
    }

    public function findByIdentifier(string $identifier): ?League
    {
        return League::where('id', $identifier)->orWhere('leaguename', $identifier)->orWhere('name', $identifier)->first();
    }
}

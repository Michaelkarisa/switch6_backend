<?php

namespace App\Services;

use App\Models\Advertisement;
use App\Models\Event;

class AdvertisementService
{
    public function __construct(
        private AdTargetingService $targeting,
        private AdEventService $events
    ) {}

    public function selectForMatch(string $matchId, string $period)
    {
        return $this->targeting->pickBestAd($matchId, $period);
    }

    public function create(array $data)
    {
        return Advertisement::create($data);
    }
}
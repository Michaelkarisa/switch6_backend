<?php

namespace App\Services;

use Illuminate\Http\JsonResponse;
use Illuminate\Pagination\LengthAwarePaginator;

/**
 * Centralised JSON response factory.
 *
 * Every response follows this envelope:
 *
 * SUCCESS
 * {
 *   "success": true,
 *   "message": "Human-readable description",
 *   "data":    <object|array|null>,
 *   "meta":    <pagination|batch summary|null>   // only when relevant
 * }
 *
 * ERROR
 * {
 *   "success": false,
 *   "message": "Human-readable description",
 *   "errors":  <validation bag|null>,
 *   "data":    null
 * }
 */
class ApiResponseService
{
    // ── Success responses ─────────────────────────────────────────

    /**
     * Standard success response.
     *
     * @param  mixed       $data     The payload (model, collection, array, null)
     * @param  string      $message  Human-readable summary
     * @param  array|null  $meta     Optional extra top-level fields (pagination, counts, ids…)
     * @param  int         $status   HTTP status code (default 200)
     */
    public static function success(
        mixed  $data    = null,
        string $message = 'Success',
        ?array $meta    = null,
        int    $status  = 200,
    ): JsonResponse {
        $body = [
            'success' => true,
            'message' => $message,
            'data'    => $data,
        ];

        if (! empty($meta)) {
            $body['meta'] = $meta;
        }

        return response()->json($body, $status);
    }

    /**
     * Paginated collection response.
     * Automatically extracts pagination metadata from a LengthAwarePaginator.
     */
    public static function paginated(
        LengthAwarePaginator $paginator,
        string $message = 'Data fetched successfully',
    ): JsonResponse {
        return response()->json([
            'success' => true,
            'message' => $message,
            'data'    => $paginator->items(),
            'meta'    => [
                'current_page' => $paginator->currentPage(),
                'per_page'     => $paginator->perPage(),
                'total'        => $paginator->total(),
                'last_page'    => $paginator->lastPage(),
                'from'         => $paginator->firstItem(),
                'to'           => $paginator->lastItem(),
            ],
        ]);
    }

    /**
     * Batch-operation response (create-many, import, etc.)
     */
    public static function batch(
        array  $items,
        int    $requested,
        string $resource = 'items',
        int    $status   = 201,
    ): JsonResponse {
        $created = count($items);

        return response()->json([
            'success' => true,
            'message' => "Successfully created {$created} {$resource}.",
            'data'    => $items,
            'meta'    => [
                'total_requested'    => $requested,
                'successfully_added' => $created,
                'failed'             => $requested - $created,
            ],
        ], $status);
    }

    /**
     * 201 Created shorthand.
     */
    public static function created(
        mixed  $data,
        string $message = 'Created successfully',
        ?array $meta    = null,
    ): JsonResponse {
        return static::success($data, $message, $meta, 201);
    }

    /**
     * 204 No-content shorthand (body-less).
     */
    public static function noContent(): JsonResponse
    {
        return response()->json(null, 204);
    }

    // ── Error responses ───────────────────────────────────────────

    /**
     * Standard error response.
     *
     * @param  string      $message  Human-readable explanation
     * @param  int         $status   HTTP status code (default 500)
     * @param  mixed|null  $errors   Validation errors or debug detail
     */
    public static function error(
        string $message,
        int    $status = 500,
        mixed  $errors = null,
    ): JsonResponse {
        return response()->json([
            'success' => false,
            'message' => $message,
            'errors'  => $errors,
            'data'    => null,
        ], $status);
    }

    /** 400 Bad Request */
    public static function badRequest(string $message = 'Bad request', mixed $errors = null): JsonResponse
    {
        return static::error($message, 400, $errors);
    }

    /** 401 Unauthenticated */
    public static function unauthenticated(string $message = 'Unauthenticated'): JsonResponse
    {
        return static::error($message, 401);
    }

    /** 403 Forbidden */
    public static function forbidden(string $message = 'Forbidden'): JsonResponse
    {
        return static::error($message, 403);
    }

    /** 404 Not Found */
    public static function notFound(string $message = 'Resource not found'): JsonResponse
    {
        return static::error($message, 404);
    }

    /** 409 Conflict */
    public static function conflict(string $message = 'Conflict'): JsonResponse
    {
        return static::error($message, 409);
    }

    /** 422 Unprocessable Entity (validation) */
    public static function validationError(mixed $errors, string $message = 'Validation failed'): JsonResponse
    {
        return static::error($message, 422, $errors);
    }
}

<?php

namespace App\Services;

use App\Models\Club;

class ClubService
{
    public function __construct(private AuditLogService $audit) {}

    public function list(?string $search = null)
    {
        return Club::with('players')
            ->when($search, fn ($q) => $q->where('name', 'like', "%{$search}%"))
            ->orderBy('name')
            ->get();
    }

    public function create(array $data): Club
    {
        $club = Club::create($data);
        $this->audit->log('created', 'clubs', 'Club created', ['club_id' => $club->id], $club);
        return $club;
    }

    public function createMany(array $items): array
    {
        $created = [];
        foreach ($items as $data) $created[] = $this->create($data);
        return $created;
    }

    public function findByIdentifier(string $identifier): ?Club
    {
        return Club::with('players')->where('id', $identifier)->orWhere('name', $identifier)->first();
    }

    public function delete(Club $club): void
    {
        $id = $club->id;
        $club->delete();
        $this->audit->log('deleted', 'clubs', 'Club deleted', ['club_id' => $id]);
    }
}

<?php

namespace App\Services;

use App\Models\Lineup;
use App\Models\MatchModel;
use Illuminate\Support\Facades\DB;

class LineupService
{
    public function __construct(private AuditLogService $audit) {}

public function storeMany(array $items): array
{
    return DB::transaction(function () use ($items) {
        $saved = [];

        foreach ($items as $data) {
            $data['is_starter'] = $data['is_starter'] ?? true;

            $lineup = Lineup::where('match_id', $data['match_id'])
                ->where('player_id', $data['player_id'])
                ->first();

            if ($lineup) {
                // Only update if something actually changed
                $changed = array_filter($data, fn($value, $key) =>
                    isset($lineup->$key) && $lineup->$key != $value,
                    ARRAY_FILTER_USE_BOTH
                );

                if (!empty($changed)) {
                    $lineup->update($data);
                    $this->audit->log('updated', 'lineups', 'Lineup updated', [
                        'lineup_id' => $lineup->id,
                        'changes'   => $changed,
                    ]);
                }

                $saved[] = $lineup->fresh();
            } else {
                $saved[] = Lineup::create($data);
                $this->audit->log('created', 'lineups', 'Lineup created', [
                    'match_id'  => $data['match_id'],
                    'player_id' => $data['player_id'],
                ]);
            }
        }

        $this->audit->log('created_many', 'lineups', 'Lineups synced', ['count' => count($saved)]);

        return $saved;
    });
}

    public function deleteByMatch(MatchModel $match): int
    {
        $deleted = Lineup::where('match_id', $match->id)->delete();

        if ($deleted > 0) {
            $this->audit->log('deleted_many', 'lineups', 'Match lineups deleted', [
                'match_id' => $match->id,
                'deleted'  => $deleted,
            ], $match);
        }

        return $deleted;
    }
}
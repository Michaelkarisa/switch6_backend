<?php

namespace App\Services;

use App\Models\Login;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class AuthService
{
    public function __construct(private AuditLogService $audit) {}

    public function register(array $data): array
    {
        $user = User::create([
            ...$data,
            'password' => Hash::make($data['password']),
        ]);

        $token = $user->createToken('api-token')->plainTextToken;

        $this->audit->log(
            'created',
            'auth',
            'User registered',
            ['email' => $user->email],
            $user,
            userId: $user->id
        );

        return [
            'token' => $token,
            'user' => [
                'id' => $user->id,
                'name' => $user->name,
                'phone' => $user->phone,
                'email' => $user->email,
                'role' => $user->role,
            ],
        ];
    }

    public function login(array $data): array
    {
        $user = User::where('email', $data['email'])->first();

        if (! $user || ! Hash::check($data['password'], $user->password)) {
            $this->audit->log(
                'failed_login',
                'auth',
                'Login failed',
                ['email' => $data['email']]
            );

            abort(response()->json([
                'success' => false,
                'message' => 'Invalid credentials',
                'errors'  => null,
                'data'    => null,
            ], 401));
        }

        Login::create([
            'user_id' => $user->id,
        ]);

        $user->tokens()->delete();

        $token = $user->createToken('api-token')->plainTextToken;

        $this->audit->log(
            'login',
            'auth',
            'User logged in',
            [],
            $user,
            userId: $user->id
        );

        return [
            'token' => $token,
            'user'  => [
                'id'    => $user->id,
                'name'  => $user->name,
                'email' => $user->email,
                'phone' => $user->phone,
                'role'  => $user->role,
            ],
        ];
    }

    public function changePassword(User $user, array $data): void
    {
        if (! Hash::check($data['old_password'], $user->password)) {
            $this->audit->log(
                'failed_password_change',
                'auth',
                'Password change failed',
                [],
                $user,
                userId: $user->id
            );

            abort(response()->json([
                'success' => false,
                'message' => 'Old password is incorrect',
                'errors'  => null,
                'data'    => null,
            ], 401));
        }

        $user->update([
            'password' => Hash::make($data['new_password']),
        ]);

        $this->audit->log(
            'password_changed',
            'auth',
            'Password changed',
            [],
            $user,
            userId: $user->id
        );
    }

    public function logout(User $user): void
    {
        $token = $user->currentAccessToken();

        if ($token) {
            $token->delete();

            $this->audit->log(
                'logout',
                'auth',
                'User logged out',
                [],
                $user,
                userId: $user->id
            );

            return;
        }

        $this->audit->log(
            'logout_without_token',
            'auth',
            'Logout attempted without active token',
            [],
            $user,
            userId: $user->id
        );
    }

    public function deleteUser(User $user): void
    {
        $id = $user->id;
        $email = $user->email;

        $this->audit->log(
            'delete_attempt',
            'users',
            'User deletion initiated',
            [
                'user_id' => $id,
                'email' => $email,
            ],
            $user,
            userId: $id
        );

        $user->tokens()->delete();
        $user->delete();

        $this->audit->log(
            'deleted',
            'users',
            'User deleted',
            [
                'user_id' => $id,
                'email' => $email,
            ]
        );
    }
}
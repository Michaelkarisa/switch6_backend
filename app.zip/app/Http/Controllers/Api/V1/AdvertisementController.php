<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreAdvertisementRequest;
use App\Models\Advertisement;
use App\Services\AdvertisementService;
use App\Services\ApiResponseService as Api;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class AdvertisementController extends Controller
{
    public function __construct(private AdvertisementService $service) {}

    /** GET /v1/ads */
    public function index(Request $request): JsonResponse
    {
        $ads = $this->service->listForUser($request->user());

        return Api::success($ads, 'Advertisements fetched successfully');
    }

    /** POST /v1/ads */
    public function store(Request $request): JsonResponse
    {
        $ad = $this->service->create($request->all());

        return Api::created($ad, 'Advertisement created successfully', ['advertisement_id' => $ad->id ?? null]);
    }

    /** GET /v1/ads/{advertisement} */
    public function show(Advertisement $advertisement): JsonResponse
    {
        return Api::success($advertisement, 'Advertisement fetched successfully');
    }

    /** DELETE /v1/ads/{advertisement} */
    public function destroy(Advertisement $advertisement): JsonResponse
    {
        $this->service->delete($advertisement);

        return Api::success(null, 'Advertisement deleted successfully');
    }

    /** GET /v1/ads/select */
    public function select(Request $request): JsonResponse
    {
        $ad = $this->service->selectForMatch(
            $request->match_id,
            $request->period,
        );

        if (! $ad) {
            return Api::notFound('No eligible advertisement found for this match/period');
        }

        return Api::success($ad, 'Advertisement selected for stream injection');
    }
}

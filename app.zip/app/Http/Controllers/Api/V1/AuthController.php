<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Requests\ChangePasswordRequest;
use App\Http\Requests\LoginRequest;
use App\Http\Requests\RegisterRequest;
use App\Models\User;
use App\Services\ApiResponseService as Api;
use App\Services\AuthService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class AuthController extends Controller
{
    public function __construct(private AuthService $auth) {}

    /** POST /v1/auth/register */
    public function register(RegisterRequest $request): JsonResponse
    {
        $result = $this->auth->register($request->validated());

        return Api::created(
            [
                'token' => $result['token'],
                'user'  => $result['user'],
            ],
            'User registered successfully',
        );
    }

    /** POST /v1/auth/login */
    public function login(LoginRequest $request): JsonResponse
    {
        $result = $this->auth->login($request->validated());

        return Api::success(
            [
                'token' => $result['token'],
                'user'  => $result['user'],
            ],
            'Login successful',
        );
    }

    /** POST /v1/auth/change-password */
    public function changePassword(ChangePasswordRequest $request): JsonResponse
    {
        $this->auth->changePassword($request->user(), $request->validated());

        return Api::success(null, 'Password changed successfully');
    }

    /** POST /v1/auth/logout */
    public function logout(Request $request): JsonResponse
    {
        $this->auth->logout($request->user());

        return Api::success(null, 'Logged out successfully');
    }

    /** DELETE /v1/users/{user} */
    public function destroyUser(User $user): JsonResponse
    {
        $this->auth->deleteUser($user);

        return Api::success(null, 'User deleted successfully');
    }
}

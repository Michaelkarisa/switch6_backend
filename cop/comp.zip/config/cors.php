<?php

return [

    'paths' => [
        'api/*',
        'v1/*',
        'sanctum/csrf-cookie',
    ],

    'allowed_methods' => ['*'],

    'allowed_origins' => [
        'http://127.0.0.1:8000',
        'http://127.0.0.1:5500',
        'http://localhost:5500',

        'http://127.0.0.1:3000',
        'http://localhost:3000',

        'http://127.0.0.1:5173',
        'http://localhost:5173',
        
    ],

    'allowed_origins_patterns' => [],

    'allowed_headers' => ['*'],

    'exposed_headers' => [],

    'max_age' => 0,

    'supports_credentials' => false,
];